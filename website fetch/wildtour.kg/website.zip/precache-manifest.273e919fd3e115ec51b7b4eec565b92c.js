self.__precacheManifest = [
  {
    "revision": "28199bbc569eb7999c9eb4165d96f1c7",
    "url": "/static/media/logo.28199bbc.svg"
  },
  {
    "revision": "909307729ba178c08e4bcbb843666802",
    "url": "/static/media/BebasNeueBook.90930772.eot"
  },
  {
    "revision": "8013005f7e72b49da573633cd796b685",
    "url": "/static/media/BebasNeueBook.8013005f.woff"
  },
  {
    "revision": "176d75276e8f67cafd70d6b50fed4e7e",
    "url": "/static/media/BebasNeueBook.176d7527.ttf"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "2e09c4b47db9848e9373",
    "url": "/static/js/main.2e09c4b4.chunk.js"
  },
  {
    "revision": "1861f51c73063f041187",
    "url": "/static/js/1.1861f51c.chunk.js"
  },
  {
    "revision": "2e09c4b47db9848e9373",
    "url": "/static/css/main.c5399e54.chunk.css"
  },
  {
    "revision": "2a1394e6c904ba01d5ee09754e602d87",
    "url": "/index.html"
  }
];